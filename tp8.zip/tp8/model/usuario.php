<?php

final class Usuario{

    public $id;
    public $nombre;
    public $apellido;
    public $email;
    public $clave;
     

};
?>